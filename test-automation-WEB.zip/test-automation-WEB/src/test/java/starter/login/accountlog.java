package starter.login;

public class accountlog {
    public static Integer id = 999;
}
