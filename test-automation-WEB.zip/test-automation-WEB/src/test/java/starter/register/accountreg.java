package starter.register;

public class accountreg {
    public static Integer id = 123;
}
